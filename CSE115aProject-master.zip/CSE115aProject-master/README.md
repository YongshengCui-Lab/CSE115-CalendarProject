# CSE115aProject
Setting up Django
- pip install django
- ./manage.py migrate
- ./manage.py runserver

Setting up React-Redux
- sudo npm install -g create-react-app
- npm install react-redux redux redux-logger
- npm start