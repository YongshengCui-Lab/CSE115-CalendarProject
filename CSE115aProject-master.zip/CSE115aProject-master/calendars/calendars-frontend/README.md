#LEAPCAL
When loading newly committed code. Remember to run:
	npm install
	npm update
before you run either:
	npm start
	npm build
ALSO, whenever loading a new library, make sure you add the flag
of --save or --save-dev  don't just install the library.

For documentation and further details go to http://jasonwatmore.com/post/2017/09/16/react-redux-user-registration-and-login-tutorial-example
